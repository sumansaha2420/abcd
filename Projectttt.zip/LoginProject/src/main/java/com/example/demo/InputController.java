package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.MicroService1;



@RestController
public class InputController 
{
	@Autowired
	private RestTemplate rest;
	
	@RequestMapping("/Login")
	public ModelAndView LoginPage()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("LoginPage.jsp");
		return mv;
	}

	@RequestMapping("Registration")
	public ModelAndView RegPge()
	{
		MicroService1 user=new MicroService1();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Registration.jsp");
		rest.postForObject("http://localhost:3001/second", user, String.class);
		return mv;
	}
	
	
}
