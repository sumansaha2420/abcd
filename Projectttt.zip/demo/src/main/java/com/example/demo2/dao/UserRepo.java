package com.example.demo2.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo2.User;

public interface UserRepo extends CrudRepository<User, Integer>
{

}
