package com.example.demo2;

import com.example.demo2.dao.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MicroService2 {
	
	@Autowired
	UserRepo repo;
	
	@RequestMapping("/second")
	public String home(@RequestBody User user)
	{
		repo.save(user);
		return "";
	}
}
